﻿This library has been compiled using Microsoft C/C++ 6.0.

Only the code and export definition files are included in this distribution of the source code. You will need to create a project and import these files yourself for compilation.

The encoding used by the files is US-ASCII (alternatively UTF-8 without BOM).