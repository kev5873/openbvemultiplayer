----------------------------------------
OpenBVE Multiplayer | Codename Lexington
----------------------------------------

This is a fork of the original OpenBve, which can be found here, http://odakyufan.zxq.net/openbve/index.html

This add-on will enable multiplayer support on this single player only game.

OpenBve is in public domain.
Any further additions in this github are under http://creativecommons.org/licenses/by-nc-sa/3.0/

Feel free to build upon this source code.  Thanks!