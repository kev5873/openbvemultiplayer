﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace OpenBve.OldCode {
	public partial class formPackage : Form {
		public formPackage() {
			InitializeComponent();
		}
		
		
		
	}
}