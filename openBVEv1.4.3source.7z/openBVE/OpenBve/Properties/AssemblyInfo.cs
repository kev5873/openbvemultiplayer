﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("openBVE")]
[assembly: AssemblyProduct("openBVE")]
[assembly: AssemblyCopyright("The openBVE Project")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.4.3.0")]
[assembly: AssemblyFileVersion("1.4.3.0")]
[assembly: CLSCompliant(true)]

namespace OpenBve {
	internal static partial class Program {
		internal const bool IsDevelopmentVersion = false;
		internal const string VersionSuffix = "";
	}
}