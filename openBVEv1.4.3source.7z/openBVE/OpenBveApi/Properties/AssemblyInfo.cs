﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("openBVE API Class Library")]
[assembly: AssemblyProduct("openBVE")]
[assembly: AssemblyCopyright("The openBVE Project")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("1.3.2.0")]