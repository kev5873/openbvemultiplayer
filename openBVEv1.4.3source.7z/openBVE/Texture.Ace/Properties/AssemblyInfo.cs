﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MSTS ACE Texture Loader")]
[assembly: AssemblyDescription("Supports loading the MSTS ACE texture file format.")]
[assembly: AssemblyProduct("openBVE")]
[assembly: AssemblyCopyright("The openBVE Project")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("0.0.0.0")]